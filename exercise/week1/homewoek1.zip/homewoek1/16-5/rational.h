#ifndef _RATIONAL_H_
#define _RATIONAL_H_

typedef struct rationalT{
	int num;
	int den;
}rationalT;

#endif
